/**
 * Class: Addable.java
 * 
 * @author ebrannoc
 * @version 1.0
 *          <p>
 * Course : ITEC 2150 Fall 2014 
 * Written: Oct 6, 2015
 * 
 * 
 *  This class � ******
 * 
 *  Purpose: � ******
 */

/**
 * @author ebrannoc
 *
 */
public interface Addable
{
	public abstract double add(double a, double b);
}
