/**
 * Class: MyFirstFileTester.java
 * 
 * @author ebrannoc
 * @version 1.0
 *          <p>
 * Course : ITEC 2150 Fall 2014 
 * Written: Oct 8, 2015
 * 
 * 
 *  This class � ******
 * 
 *  Purpose: � ******
 */

/**
 * @author ebrannoc
 *
 */
public class MyFirstFileTester
{

	public static void main(String[] args)
	{
		OurFirstFile off = new OurFirstFile("names.txt", "backwardsnames.txt"); 
		off.readAndWriteFile();
		off.closeAll();		
	}
}
