/**
 * Class: Person.java
 * 
 * @author ebrannoc
 * @version 1.0
 *          <p>
 * Course : ITEC 2150 Fall 2014 
 * Written: Oct 8, 2015
 * 
 * 
 *  This class � ******
 * 
 *  Purpose: � ******
 */

/**
 * @author ebrannoc
 *
 */
public class Person implements Comparable<Person>
{

	private String firstName;
	private String lastName;
	private int bannerId;
	private int numHours;
	private String zip;

	public Person()
	{		
		this.firstName = "default";
		this.lastName = "default";
		this.setBannerId(900099999);
		this.setNumHours(0);
		this.setZip("99999");
	}

	public Person(String firstName, String lastName, String bannerId, String numHours, String zip)
	{		
		this.firstName = firstName;
		this.lastName = lastName;
		this.setBannerId(bannerId);
		this.setNumHours(numHours);
		this.setZip(zip);
	}

	public String getFirstName()
	{
		return firstName;
	}

	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	public String getLastName()
	{
		return lastName;
	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public int getBannerId()
	{
		return bannerId;
	}	
	public void setBannerId(int bannerId)
	{
		this.setBannerId("" + bannerId);
	}

	public void setBannerId(String bannerId)
	{
		String regex9000 = "(900)[0|1]\\d{5}";  
		if (bannerId.matches(regex9000))
		{			
			this.bannerId = Integer.parseInt(bannerId);			
		}
		else
		{
			System.out.println("Invalid banner id");
			this.bannerId = 900099999;			
		}
	}	

	public int getNumHours()
	{
		return numHours;
	}

	public void setNumHours(int numHours)
	{
		this.numHours = numHours;
	}
	
	public void setNumHours(String numHours)
	{
		try
		{
			this.numHours = Integer.parseInt(numHours);
		} catch (NumberFormatException nfe)
		{
			nfe.printStackTrace();
			System.out.println("Invalid number for num of hours");
			this.numHours = 0;
		}		
	}

	public String getZip()
	{
		return zip;
	}

	public void setZip(String zip)
	{
		String regexZip = "\\d{5}|\\d{5}-\\d{4}"; 
		if (zip.matches(regexZip))
		{			
			this.zip = zip;
		}
		else
		{
			System.out.println("Invalid zip");
			this.zip = "999999";
		}		
	}
	
	public String getClassification()
	{
		if (this.numHours >= 90) return "Senior";
		else if (this.numHours >= 60) return "Junior";
		else if (this.numHours >= 30) return "Soph";
		else if (this.numHours >= 0) return "Freshman";
		else return "Error";
	}

	@Override
	public String toString()
	{
		return firstName + ", " + lastName
				+ ", " + bannerId + ", " + numHours
				+ ", " + zip;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Person p)
	{
		if (this.getLastName().equalsIgnoreCase(p.getLastName())) return 0;
		else if (this.getLastName().compareToIgnoreCase(p.getLastName()) < 0) return -1; 
		return 1;
	}

}
