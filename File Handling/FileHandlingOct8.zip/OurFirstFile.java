import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 * Class: OurFirstFile.java
 * 
 * @author ebrannoc
 * @version 1.0
 *          <p>
 * Course : ITEC 2150 Fall 2014 
 * Written: Oct 6, 2015
 * 
 * 
 *  This class � ******
 * 
 *  Purpose: � ******
 */

public class OurFirstFile
{

	private File fr; 
	private PrintWriter pw; 
	private Scanner sc;


	public OurFirstFile()
	{
		this.fr = null;
		this.pw = null;
		this.sc = null;
	}


	public OurFirstFile(String inputFile, String outputFile)
	{
		try
		{
			fr = new File(inputFile);
			pw = new PrintWriter(outputFile);
			sc = new Scanner(fr);
		} catch (FileNotFoundException fnfe)
		{
			fnfe.printStackTrace();
			System.out.println("File not found");
		} catch (Exception e)
		{
			e.printStackTrace();
			System.out.println("Unexpected error");

		}
	}

	public void readAndWriteFile()
	{
		ArrayList<Person> pAL = new ArrayList<Person>();
		pw.println("Person Info");
		while (sc != null && sc.hasNext())
		{
			String personLine = sc.nextLine();
			String[] splitPersonLine = personLine.split(" ");
			if (splitPersonLine.length > 4)
			{				
				Person person = new Person(splitPersonLine[0], splitPersonLine[1],splitPersonLine[2],splitPersonLine[3], splitPersonLine[4]);
				pAL.add(person);
				//System.out.println(person);
				//pw.println(person.getLastName() + ", " + person.getFirstName() + ", " + person.getZip() + ", " + person.getBannerId() + ", " + person.getNumHours());
			}		
		}
		Collections.sort(pAL);
		for (Person p: pAL)  { pw.println(p); }		
	}

	public void closeAll()
	{
		sc.close(); //to prevent memory leakage
		pw.close();	
		//must close printwriter -- takes info from buffer (RAM) and writes to hard drive
	}


}
